<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Gestion_Ress extends CI_Controller
{
	public function index()
	{
		$personnes = array(
			0 => array('noms' => 'Jessy1', 'nbrePlace' => 'Brown1', 'description' => '00001111', 'electric' => 'Brown1'),
			1 => array('noms' => 'Jessy2', 'nbrePlace' => 'Brown2', 'description' => '00001111', 'electric' => 'Brown2'),
			2 => array('noms' => 'Jessy3', 'nbrePlace' => 'Brown3', 'description' => '00001111', 'electric' => 'Brown3')
		);
		$data = array();
		$data['personnes'] = $personnes;
		$this->load->view('G_Ress_view', $data);
	}
}
